<?php
	require_once('auth.php');
?>
<?php

/*

EDIT.PHP

Allows user to edit specific entry in database

*/



// creates the edit record form

// since this form is used multiple times in this file, I have made it a function that is easily reusable
 

function renderForm($id, $firstname, $lastname, $role, $phone, $email,$age,$gender,$city, $error)

{

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>

<head>

<title>Myriad Online</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>

    <style>
html,
body,
.login-box {
  height: 100%;
}
.top_div{
	background-color: #bdbdbd;
}

#top_div {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 50%;
  background-color:#ef5350;
  z-index: -1;
  text-align:center;
  background-repeat: no-repeat;
   background-attachment: fixed;
   
}
.inlineradio{
  display: inline;
  padding: 5px;
}
#firstnameinput,#lastnameinput,#professioninput,#classinput,#ageinput,#sexinput,#cityinput,#deptinput{
  display: none;
}
  </style> 
</head>

<body>
 <div class="col s12">
      <ul class="tabs">
        <li class="tab col s3"><a  class ="active" href="home.php">Home</a></li>
        <li class="tab col s3"><a  href="view.php" target="_self">View</a></li>
        <li class="tab col s3"><a href="new.php" >Add</a></li>
        <li class="tab col s3"><a href="index.php" target="_self">Log Out</a></li>
      </ul>
    </div>
<?php

// if there are any errors, display them

if ($error != '')

{

echo '<div style="padding:4px; border:1px solid red; color:red;">'.$error.'</div>';

}

echo ' <div id="top_div"> ';

echo "</div>";
// display data in table

echo '<div id="editsection" class="col s12">';
echo '<br><br>';   
            echo '<div class = "row center">';
            echo '<div class = "col s12">';
            echo '<h3 class="white-text">Edit Member Details</h3>';
            echo '</div>';
            echo '</div>';

 echo '<div class="container">';
 echo '<div class = "card-panel">';
 echo ' <br><h5  class="grey-text thin" Edit Members</h5><br><br> ';


?>



<form action="" method="post">

<input type="hidden" name="id" value="<?php echo $id; ?>"/>

<div>

<p><strong>ID:</strong> <?php echo $id; ?></p>

<strong>First Name: *</strong> <input type="text" name="firstname" value="<?php echo $firstname; ?>"/><br/>

<strong>Last Name: *</strong> <input type="text" name="lastname" value="<?php echo $lastname; ?>"/><br/>

<strong>Role: *</strong>
  <p>
      <input name="role" type="radio" id="test1" value="Member" />
      <label for="test1">Member</label>
    </p>
    <p>
      <input name="role" type="radio" id="test2" value="Admin" />
      <label for="test2">Admin</label>
    </p><br>



<strong>Phone: *</strong> <input type="text" name="phone" value="<?php echo $phone; ?>" /><br/>
<strong>Email: *</strong> <input type="text" name="email" value="<?php echo $email; ?>" /><br/>
<strong>Age: *</strong> <input type="text" name="age" value="<?php echo $age; ?>" /><br/>
<strong>Gender: *</strong> <input type="text" name="gender" value="<?php echo $gender; ?>" /><br/>
<strong>City: *</strong> <input type="text" name="city" value="<?php echo $city; ?>" /><br/>

<p>* Required</p>

<div class="center">
<input  class="btn btn-large waves-effect  waves-light red" type="submit" name="submit" value="Submit">
</div>

</div>

</form>

</body>

</html>

<?php

}







// connect to the database

include('connect-db.php');



// check if the form has been submitted. If it has, process the form and save it to the database

if (isset($_POST['submit']))

{

// confirm that the 'id' value is a valid integer before getting the form data

if (is_numeric($_POST['id']))

{

// get form data, making sure it is valid

$id = $_POST['id'];

$firstname = mysql_real_escape_string(htmlspecialchars($_POST['firstname']));

$lastname = mysql_real_escape_string(htmlspecialchars($_POST['lastname']));

$role = mysql_real_escape_string(htmlspecialchars($_POST['role']));
$phone = mysql_real_escape_string(htmlspecialchars($_POST['phone']));
$email = mysql_real_escape_string(htmlspecialchars($_POST['email']));
$age = mysql_real_escape_string(htmlspecialchars($_POST['age']));
$gender = mysql_real_escape_string(htmlspecialchars($_POST['gender']));
$city = mysql_real_escape_string(htmlspecialchars($_POST['city']));



// check that firstname/lastname fields are both filled in

if ($firstname == '' || $lastname == '')

{

// generate error message

$error = 'ERROR: Please fill in all required fields!';



//error, display form

renderForm($id, $firstname, $lastname, $role, $phone, $email,$age,$gender,$city, $error);

}

else

{

// save the data to the database

mysql_query("UPDATE user SET firstname='$firstname', lastname='$lastname', role='$role', phone='$phone', email='$email', age='$age', gender='$gender', city='$city' WHERE id='$id'")

or die(mysql_error());



// once saved, redirect back to the view page

header("Location: view.php");

}

}

else

{

// if the 'id' isn't valid, display an error

echo 'Error!';

}

}

else

// if the form hasn't been submitted, get the data from the db and display the form

{



// get the 'id' value from the URL (if it exists), making sure that it is valid (checking that it is numeric/larger than 0)

if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0)

{

// query db

$id = $_GET['id'];

$result = mysql_query("SELECT * FROM user WHERE id=$id")

or die(mysql_error());

$row = mysql_fetch_array($result);



// check that the 'id' matches up with a row in the databse

if($row)

{



// get data from db

$firstname = $row['firstname'];

$lastname = $row['lastname'];

$role = $row['role'];

$phone = $row['phone'];

$email = $row['email'];

$age = $row['age'];

$gender = $row['gender'];

$city = $row['city'];





// show form

renderForm($id, $firstname, $lastname, $role, $phone, $email, $age, $gender, $city, '');

}

else

// if no match, display result

{

echo "No results!";

}

}

else

// if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error

{

echo 'Error!';

}

}

?>

