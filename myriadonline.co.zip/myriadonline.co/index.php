<?php
  //Start session
  session_start();  
  //Unset the variables stored in session
  unset($_SESSION['SESS_MEMBER_ID']);
  unset($_SESSION['SESS_FIRST_NAME']);
  unset($_SESSION['SESS_LAST_NAME']);
?>

<?php

/*

NEW.PHP

Allows user to create a new entry in the database

*/



// creates the new record form

// since this form is used multiple times in this file, I have made it a function that is easily reusable

function renderForm($orgname1, $username1, $email1, $password1, $error)

{



?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Myriad Online</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <style>
html,
body,
.login-box {
  height: 100%;

}
.top_div{
	background-color: #bdbdbd;
	
	
}
html{
	overflow: hidden;
  background-color:#ef5350;
}

#top_div {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 50%;
  background-color:#ef5350;
 z-index: 1;

  text-align:center;
  background-repeat: no-repeat;
    
   background-attachment: fixed;
   
}



  </style> 
</head>

<body>
  <br><br><br>

  <br><h3 style="text-align: center;" class="white-text" >Myriad Online</h3>
  
  <h5 style="text-align: center;" class="white-text thin" >&quot;An organization for your organization. &quot;</h5><br>


<div class="container"><div class="container">
<div class="col card hoverable s10 pull-s1 m6 pull-m3 l4 pull-l4 ">
<form name="loginform" action="login_exec.php" method="post" >
 
 
<div class="card center orange white-text">
    <!--the code bellow is used to display the message of the input validation-->
     <?php
      if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
      echo '<ul class="err">';
      foreach($_SESSION['ERRMSG_ARR'] as $msg) {
        echo '<li>',$msg,'</li>'; 
        }
      echo '</ul>';
      unset($_SESSION['ERRMSG_ARR']);
      }
    ?>
  </div>
<div class="container">
  <br><br>
    <div align="center">Username</div>
    <input name="username" type="text">
  
  
    <div align="center">Password</div>
    <input name="password" type="text">
  
  <br>
    <div align="center">
    <input name="" type="submit" value="login" class="btn btn-large waves-effect  waves-light green" > 
   <button data-target="modal1" class="btn-large grey modal-trigger">Register</button>

 
   
    </div>
    <br><br>
</div>
</form>
  </div>
</div>
</div>


      <!-- Modal Structure -->
  <div id="modal1" class="modal modal-fixed-footer">
    
    
    <div class="modal-content">
      <div id="login-page" class="row">
    
      <form class="login-form">
        <div class="row">
          <div class="input-field col s12 center">
            <h4>Register</h4>
            <p class="center"> Create an account.</p>
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            
             <strong>Organization: *</strong><input type="text" name="orgname" value="<?php echo $orgname; ?>" />
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
           
            <strong>Username: *</strong><input type="text" name="username" value="<?php echo $username; ?>" />
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            
            <strong>Email: *</strong><input type="text" name="email" value="<?php echo $email; ?>" />
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            
            <strong>Password: *</strong><input type="text" name="password" value="<?php echo $password; ?>" />
          </div>
        </div>
        
        <div class="row center container">
          <div class="input-field col s12">
          <input name="" type="submit" value="Register" class="btn btn-large waves-effect  waves-light green" > 
            
          </div>
        
        </div>
      </form></div></div></div>
      
      
 <p class="thin grey-text"> Database 4402 (2016) </p>	
		
  

 

  
 
    
  
  

 

  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
  <script>
  $(document).ready(function(){
    // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
    $('.modal-trigger').leanModal();
  });
  
    $(document).ready(function(){
    // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });
  
  </script>

  </body>
</html>

<?php

}









// connect to the database

include('connect-db.php');



// check if the form has been submitted. If it has, start to process the form and save it to the database

if (isset($_POST['submit']))

{

// get form data, making sure it is valid

$orgname = mysql_real_escape_string(htmlspecialchars($_POST['orgname']));
$username = mysql_real_escape_string(htmlspecialchars($_POST['username']));
$email = mysql_real_escape_string(htmlspecialchars($_POST['email']));
$password = mysql_real_escape_string(htmlspecialchars($_POST['password']));




// check to make sure both fields are entered

if ($username == '' || $password == '')

{

// generate error message

$error = 'ERROR: Please fill in all required fields!';



// if either field is blank, display the form again



}

else

{

// save the data to the database

mysql_query("INSERT account SET orgname='$orgname', email='$email' , username='$username', password='$password'  ")

or die(mysql_error());



// once saved, redirect back to the view page

header("Location: index.php"); //was view.php

}

}

else

// if the form hasn't been submitted, display the form

{

renderForm('','','','','');

}

?>
