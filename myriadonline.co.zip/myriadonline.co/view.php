<?php
	require_once('auth.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>

<head>

<title>Myriad Online</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>

    <style>
html,
body,
.login-box {
  height: 100%;
}
.top_div{
	background-color: #bdbdbd;
}

#top_div {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 50%;
  background-color:#ef5350;
  z-index: -1;
  text-align:center;
  background-repeat: no-repeat;
   background-attachment: fixed;
   
}
.inlineradio{
  display: inline;
  padding: 5px;
}
#firstnameinput,#lastnameinput,#professioninput,#classinput,#ageinput,#sexinput,#cityinput,#deptinput{
  display: none;
}
  </style> 
</head>

<body>

 <div class="col s12">
      <ul class="tabs">
        <li class="tab col s3"><a  href="home.php" target="_self">Home</a></li>
        <li class="tab col s3"><a  class ="active" href="view.php" target="_self">View</a></li>
        <li class="tab col s3"><a href="new.php" target="_self">Add</a></li>
        <li class="tab col s3"><a href="index.php" target="_self">Log Out</a></li>
      </ul>
    </div>

<?php

/*

VIEW.PHP

Displays all data from 'members' table

*/



// connect to the database

include('connect-db.php');



// get results from database

$result = mysql_query("SELECT * FROM user")


or die(mysql_error());


echo ' <div id="top_div"> ';

echo "</div>";
// display data in table

echo '<div id="viewsection" class="col s12">';
echo '<br><br>';   
            echo '<div class = "row center">';
            echo '<div class = "col s12">';
            echo '<h3 class="white-text">View Current Entries</h3>';
            $num_rows = mysql_num_rows($result);
           
            
            echo '</div>';
            echo '</div>';
           

 echo '<div class="container">';
 echo '<div class = "card-panel">';
 echo ' <br><h5 style="text-align: center;" class="grey-text thin"Current Members</h5><br><br> ';

echo ' <div class= "center"> ';




echo "<table border='1' cellpadding='10' class='striped responsive-table center'>";

echo "<tr> <th>ID</th> <th>First Name</th> 
<th>Last Name</th> 
<th>Role</th>
<th>Number</th>
<th>Email</th>
<th>Age</th>
<th>Gender</th>
<th>City</th>
<th></th> <th></th></tr>";



// loop through results of database query, displaying them in the table

while($row = mysql_fetch_array( $result )) {



// echo out the contents of each row into a table

echo "<tr>";

echo '<td>' . $row['id'] . '</td>';
echo '<td>' . $row['firstname'] . '</td>';
echo '<td>' . $row['lastname'] . '</td>';
echo '<td>' . $row['role'] . '</td>';
echo '<td>' . $row['phone'] . '</td>';
echo '<td>' . $row['email'] . '</td>';
echo '<td>' . $row['age'] . '</td>';
echo '<td>' . $row['gender'] . '</td>';
echo '<td>' . $row['city'] . '</td>';

echo '<td><a href="edit.php?id=' . $row['id'] . '">Edit</a></td>';

echo '<td><a href="delete.php?id=' . $row['id'] . '">Delete</a></td>';

echo "</tr>";

}



// close table>

echo "</table>";

;


?>

<br><br>
<a class="btn btn-large waves-effect waves-light red" href =" new.php">Add Member</a>
</div></div></div>
<br>
<br>
<br>

 <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</body>

</html>