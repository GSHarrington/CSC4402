<?php
	require_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>Myriad Online</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
-->
html, 
body,
.login-box {
  height: 100%;
}
html{
  background-color:#ef5350;
}
.top_div{
	background-color: #bdbdbd;
}

#top_div {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 50%;
  background-color:#ef5350;
  z-index: -1;
  text-align:center;
  background-repeat: no-repeat;
   background-attachment: fixed;
   
}
.inlineradio{
  display: inline;
  padding: 5px;
}
#firstnameinput,#lastnameinput,#professioninput,#classinput,#ageinput,#sexinput,#cityinput,#deptinput{
  display: none;
}

</style>
</head>
 
<body>

	 <div class="col s12">
      <ul class="tabs">
        <li class="tab col s3"><a  class ="active" href="#">Home</a></li>
        <li class="tab col s3"><a  href="view.php" target="_self">View</a></li>
        <li class="tab col s3"><a href="new.php" >Add</a></li>
        <li class="tab col s3"><a href="index.php" target="_self">Log Out</a></li>
      </ul>
    </div>


<p align="center" class="style1 white-text">Welcome to your Organization. </p>


 <img src="image/logo.png" alt="Smiley face" class="center" style="display:block;
    margin:auto;">
<br><br>
<h5 align="center" class=" white-text">Here you can update organization records.</h5>
<br><br><br>
<div class="container white-text">
<div class="row ">
        <div class="col s12 m4 ">
          <div class="icon-block">
            <h2 class="center white-text"><i class="material-icons">visibility</i></h2>
            <h5 class="center">View Members</h5>

            <p class="light center">List current members within your group.</p>
          </div>
        </div>

        <div class="col s12 m4 ">
          <div class="icon-block">
            <h2 class="center white-text"><i class="material-icons">group</i></h2>
            <h5 class="center">Add Members</h5>

            <p class="light center">Add new members within your group.</p>
          </div>
        </div>

        <div class="col s12 m4 ">
          <div class="icon-block">
            <h2 class="center white-text"><i class="material-icons">settings</i></h2>
            <h5 class="center">Edit Members</h5>

            <p class="light center">Change info on members within your group</p>
          </div>
        </div>
      </div>
      </div> <!--End of Container-->

        
          
<br><br><br><br>
<p align="center" class=" white-text">For more help email support@Humadex.com!</p>







</body>
</html>