<?php
  require_once('auth.php');
?>
<?php

/*

NEW.PHP

Allows user to create a new entry in the database

*/



// creates the new record form

// since this form is used multiple times in this file, I have made it a function that is easily reusable

function renderForm($first, $last, $role, $phone, $email, $age, $gender, $city, $error)

{



?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>

<head>

<title>Myriad Online</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>

    <style>
html,
body,
.login-box {
  height: 100%;
}
.top_div{
	background-color: #bdbdbd;
}

#top_div {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 50%;
  background-color:#ef5350;
  z-index: -1;
  text-align:center;
  background-repeat: no-repeat;
   background-attachment: fixed;
   
}
.inlineradio{
  display: inline;
  padding: 5px;
}
#firstnameinput,#lastnameinput,#professioninput,#classinput,#ageinput,#sexinput,#cityinput,#deptinput{
  display: none;
}
  </style> 
</head>

<body>
 <div class="col s12">
      <ul class="tabs">
        <li class="tab col s3"><a class ="active" href="home.php">Home</a></li>
        <li class="tab col s3"><a href="view.php" target="_self">View</a></li>
        <li class="tab col s3"><a href="new.php" >Add</a></li>
        <li class="tab col s3"><a href="index.php" target="_self">Log Out</a></li>
      </ul>
    </div>


<?php

// if there are any errors, display them

if ($error != '')

{

echo '<div style="padding:4px; border:1px solid red; color:red;">'.$error.'</div>';

}

echo ' <div id="top_div"> ';

echo "</div>";
// display data in table

echo '<div id="addsection" class="col s12">';
echo '<br><br>';   
            echo '<div class = "row center">';
            echo '<div class = "col s12">';
            echo '<h3 class="white-text">Add Member Details</h3>';
            echo '</div>';
            echo '</div>';

 echo '<div class="container">';
 echo '<div class = "card-panel">';
 echo ' <br><h5  class="grey-text thin"Current Members</h5><br><br> ';


?>



<form action="" method="post">

<div>

<strong>First Name: *</strong> <input type="text" name="firstname" value="<?php echo $first; ?>" /><br/>
<strong>Last Name: *</strong> <input type="text" name="lastname" value="<?php echo $last; ?>" /><br/>

<strong>Role: *</strong>
  <p>
      <input name="role" type="radio" id="test1" value="Member" />
      <label for="test1">Member</label>
    </p>
    <p>
      <input name="role" type="radio" id="test2" value="Admin" />
      <label for="test2">Admin</label>
    </p>
   

    <br>
<strong>Phone: *</strong> <input type="text" name="phone" value="<?php echo $phone; ?>" /><br/>
<strong>Email: *</strong> <input type="text" name="email" value="<?php echo $email; ?>" /><br/>
<strong>Age: *</strong> <input type="text" name="age" value="<?php echo $age; ?>" /><br/>
<strong>Gender: *</strong> <input type="text" name="gender" value="<?php echo $gender; ?>" /><br/>
<strong>City: *</strong> <input type="text" name="city" value="<?php echo $city; ?>" /><br/>

<p>* required</p>
<div class="center">
<input  class="btn btn-large waves-effect  waves-light red" type="submit" name="submit" value="Submit">
</div>
</div>

</form>
 </div>
</div>
</div>

</body>

</html>

<?php

}









// connect to the database

include('connect-db.php');



// check if the form has been submitted. If it has, start to process the form and save it to the database

if (isset($_POST['submit']))

{

// get form data, making sure it is valid

$firstname = mysql_real_escape_string(htmlspecialchars($_POST['firstname']));
$lastname = mysql_real_escape_string(htmlspecialchars($_POST['lastname']));
$role = mysql_real_escape_string(htmlspecialchars($_POST['role']));
$phone = mysql_real_escape_string(htmlspecialchars($_POST['phone']));
$email = mysql_real_escape_string(htmlspecialchars($_POST['email']));
$age = mysql_real_escape_string(htmlspecialchars($_POST['age']));
$gender = mysql_real_escape_string(htmlspecialchars($_POST['gender']));
$city = mysql_real_escape_string(htmlspecialchars($_POST['city']));



// check to make sure both fields are entered

if ($firstname == '' || $lastname == '')

{

// generate error message

$error = 'ERROR: Please fill in all required fields!';



// if either field is blank, display the form again

renderForm($first, $last, $role, $phone, $email, $age, $gender, $city, $error);

}

else

{

// save the data to the database

mysql_query("INSERT user SET firstname='$firstname', lastname='$lastname' , role='$role', phone='$phone', email='$email', age='$age', gender='$gender', city='$city'  ")

or die(mysql_error());



// once saved, redirect back to the view page

header("Location: view.php"); //was view.php

}

}

else

// if the form hasn't been submitted, display the form

{

renderForm('','','','','','','','','');

}

?>

